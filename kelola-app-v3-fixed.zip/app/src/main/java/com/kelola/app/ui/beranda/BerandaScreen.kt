package com.kelola.app.ui.beranda

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kelola.app.data.local.entity.TransactionType
import com.kelola.app.data.repository.KelolaRepository
import com.kelola.app.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun BerandaScreen(repository: KelolaRepository) {
    val business by repository.getActiveBusiness().collectAsState(initial = null)
    val transactions by repository.getTransactions().collectAsState(initial = emptyList())

    val today = androidx.compose.runtime.remember {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.timeInMillis
    }
    val todaysTx = transactions.filter { it.createdAt >= today }
    val omzetHariIni = todaysTx.filter { it.type == TransactionType.PENJUALAN }.sumOf { it.totalAmount }
    val pengeluaranHariIni = todaysTx.filter { it.type == TransactionType.PENGELUARAN }.sumOf { it.totalAmount }
    val labaEstimasi = omzetHariIni - pengeluaranHariIni

    val formatter = remember { NumberFormat.getNumberInstance(Locale("in", "ID")) }
    val insight by repository.getInsightFlow().collectAsState(initial = "")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {
        Text(
            "Halo, ${business?.name ?: "Usaha Kamu"}",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = Ink
        )
        Spacer(Modifier.height(16.dp))

        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Teal,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("Omzet hari ini", color = GoodBg, style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Rp ${formatter.format(omzetHariIni)}",
                    color = Sage,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    "Estimasi laba: Rp ${formatter.format(labaEstimasi)}  ·  Transaksi: ${todaysTx.size}",
                    color = Sage.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        if (insight.isNotBlank()) {
            Surface(shape = RoundedCornerShape(14.dp), color = GoodBg, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp)) {
                    Text("\uD83D\uDCA1 ", style = MaterialTheme.typography.bodyMedium)
                    Text(insight, color = TealDeep, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        Text("Aktivitas terbaru", fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(8.dp))

        if (transactions.isEmpty()) {
            Text(
                "Belum ada transaksi. Catat transaksi pertamamu lewat tombol + di Transaksi.",
                color = InkSoft,
                style = MaterialTheme.typography.bodyMedium
            )
        } else {
            transactions.take(5).forEach { tx ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = CardSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(tx.type.name, color = Ink)
                        Text(
                            "Rp ${formatter.format(tx.totalAmount)}",
                            color = if (tx.type == TransactionType.PENJUALAN) Good else Warn,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
