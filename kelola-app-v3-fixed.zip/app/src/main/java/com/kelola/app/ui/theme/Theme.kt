package com.kelola.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp

private val KelolaColorScheme = lightColorScheme(
    primary = Teal,
    onPrimary = Sage,
    secondary = Mustard,
    onSecondary = Ink,
    background = Sage,
    onBackground = Ink,
    surface = CardSurface,
    onSurface = Ink,
    error = Warn
)

val KelolaTypography = Typography(
    titleLarge = TextStyle(fontSize = 22.sp),
    titleMedium = TextStyle(fontSize = 16.sp),
    bodyLarge = TextStyle(fontSize = 14.sp),
    bodyMedium = TextStyle(fontSize = 13.sp),
    labelSmall = TextStyle(fontSize = 11.sp)
)

@Composable
fun KelolaTheme(content: @Composable () -> Unit) {
    // Dark mode belum diaktifkan di P0 — selalu pakai skema terang dulu
    MaterialTheme(
        colorScheme = KelolaColorScheme,
        typography = KelolaTypography,
        content = content
    )
}
