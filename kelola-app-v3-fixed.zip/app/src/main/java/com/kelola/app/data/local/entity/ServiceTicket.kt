package com.kelola.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ServiceStatus { DITERIMA, DIAGNOSA, DIKERJAKAN, QC, SELESAI, DIAMBIL }

@Entity(tableName = "service_tickets")
data class ServiceTicket(
    @PrimaryKey val id: String,
    val businessId: String,
    val transactionId: String? = null,
    val customerId: String? = null,
    val deviceDesc: String,
    val complaint: String,
    val technicianId: String? = null,
    val status: ServiceStatus = ServiceStatus.DITERIMA,
    val estimatedCost: Double = 0.0,
    val finalCost: Double = 0.0,
    val warrantyDays: Int = 0,
    val warrantyUntil: Long? = null, // diisi otomatis saat status -> SELESAI
    val createdAt: Long,
    val deletedAt: Long? = null
)

/** Resep/Bill of Materials — dipakai untuk produk F&B/produksi yang punya bahan baku */
@Entity(tableName = "product_bom")
data class ProductBom(
    @PrimaryKey val id: String,
    val productId: String, // produk jadi, mis. "Kopi Susu"
    val ingredientProductId: String, // bahan baku, juga berupa Product, mis. "Susu"
    val qtyNeeded: Double // jumlah bahan baku per 1 unit produk jadi
)
