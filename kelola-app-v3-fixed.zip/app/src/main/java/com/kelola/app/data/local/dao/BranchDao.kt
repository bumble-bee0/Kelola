package com.kelola.app.data.local.dao

import androidx.room.*
import com.kelola.app.data.local.entity.Branch
import kotlinx.coroutines.flow.Flow

@Dao
interface BranchDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(branch: Branch)

    @Query("SELECT * FROM branches WHERE businessId = :businessId AND deletedAt IS NULL ORDER BY name ASC")
    fun getForBusiness(businessId: String): Flow<List<Branch>>
}
