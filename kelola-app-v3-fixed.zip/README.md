# Kelola — v1.0.0 (MVP Lengkap)

Semua tahap rancangan (P0-P3) sudah selesai, termasuk perbaikan yang
diminta terakhir:
- **Logo final "Pita Kelola"** sudah dipasang sebagai app icon (adaptive
  icon 2 layer) dan ditampilkan di layar onboarding
- **Retur** — sudah ada tombol di setiap transaksi Penjualan
- **Riwayat Aktivitas (Audit Log)** — sudah ada di layar Tim & Pengaturan
- Skema warna Kelola (Teal/Mustard/Sage/Ink) sudah diterapkan konsisten
  di semua layar

**Satu-satunya yang masih tertunda** (dicatat jujur):
- UI untuk mengatur Resep/Bahan Baku (BOM) di layar Produk — logika
  backend (`setProductBom`) sudah ada dan berfungsi, tapi belum ada
  tombol/tampilan untuk memakainya. Kalau dibutuhkan, kabari lagi untuk
  dilanjutkan di update berikutnya.
- Cloud sync — butuh server terpisah, di luar cakupan aplikasi Android

## Cara Build APK via GitHub (tanpa install Android Studio)

### 1. Buat repository baru di GitHub
- Buka github.com → klik **New repository**
- Nama bebas, misal `kelola-app`
- Pilih **Private** (biar source code tidak publik) atau Public, bebas
- JANGAN centang "Add README" (kita sudah punya)

### 2. Upload isi folder ini ke repo tersebut
Paling gampang lewat browser (tanpa command line):
- Di halaman repo GitHub, klik **Add file → Upload files**
- Extract file zip yang aku kasih, lalu drag semua isinya (folder `app`,
  `.github`, `build.gradle.kts`, `settings.gradle.kts`, `README.md`)
  ke halaman upload tersebut
- **Penting**: pastikan folder `.github` ikut ter-upload (kadang browser
  menyembunyikan folder berawalan titik — kalau tidak muncul, upload
  manual folder `.github/workflows/build-apk.yml` lewat "Create new file"
  dan ketik path lengkapnya `.github/workflows/build-apk.yml`)
- Scroll ke bawah, klik **Commit changes**

### 3. Tunggu proses build otomatis
- Klik tab **Actions** di repo kamu
- Akan muncul proses "Build Kelola APK" yang jalan otomatis setelah upload
- Tunggu sampai tanda centang hijau ✅ muncul (biasanya 3-5 menit)

### 4. Download APK-nya
- Klik hasil build yang sudah selesai (centang hijau)
- Scroll ke bawah ke bagian **Artifacts**
- Klik **kelola-debug-apk** untuk download (dalam bentuk zip, di dalamnya ada `app-debug.apk`)
- Extract, lalu kirim APK ke HP Android kamu (lewat WhatsApp/Google Drive/kabel data) untuk diinstall

### Catatan
- APK ini masih versi **debug** (untuk testing), belum untuk dipublikasi ke Play Store
- Kalau muncul warning "Install blocked" di HP, aktifkan dulu izin
  "Install dari sumber tidak dikenal" di pengaturan HP kamu
- Setiap kali aku kasih update kode tahap berikutnya (P1, P2, dst),
  caranya sama: upload file baru ke repo yang sama → Actions jalan
  otomatis lagi → download APK baru dari Artifacts
