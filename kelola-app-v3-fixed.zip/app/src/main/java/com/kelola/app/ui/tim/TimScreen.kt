package com.kelola.app.ui.tim

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kelola.app.data.local.entity.SalaryType
import com.kelola.app.data.local.entity.TransactionType
import com.kelola.app.data.repository.KelolaRepository
import com.kelola.app.ui.theme.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimScreen(businessId: String, repository: KelolaRepository) {
    val employees by repository.getEmployees(businessId).collectAsState(initial = emptyList())
    val branches by repository.getBranches(businessId).collectAsState(initial = emptyList())
    val transactions by repository.getTransactions().collectAsState(initial = emptyList())
    val auditLog by repository.getAuditLog().collectAsState(initial = emptyList())
    var showAddEmployee by remember { mutableStateOf(false) }
    var showAddBranch by remember { mutableStateOf(false) }
    var showTutupKasir by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val formatter = remember { NumberFormat.getNumberInstance(Locale("in", "ID")) }

    val expectedCash = transactions
        .filter { it.type == TransactionType.PENJUALAN }
        .sumOf { it.paidAmount } - transactions.filter { it.type == TransactionType.PENGELUARAN }.sumOf { it.totalAmount }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Tim & Pengaturan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(16.dp))

        Surface(shape = RoundedCornerShape(14.dp), color = Teal, modifier = Modifier.fillMaxWidth()) {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Column {
                    Text("Tutup Kasir", color = Sage, fontWeight = FontWeight.Bold)
                    Text("Estimasi kas: Rp ${formatter.format(expectedCash)}", color = Sage.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium)
                }
                Button(
                    onClick = { showTutupKasir = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Mustard, contentColor = Ink)
                ) { Text("Tutup") }
            }
        }

        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Karyawan", fontWeight = FontWeight.Bold, color = Ink)
            TextButton(onClick = { showAddEmployee = true }) { Text("+ Tambah", color = Teal) }
        }
        Spacer(Modifier.height(8.dp))

        if (employees.isEmpty()) {
            Text("Belum ada karyawan terdaftar.", color = InkSoft, style = MaterialTheme.typography.bodyMedium)
        } else {
            employees.forEach { emp ->
                Surface(shape = RoundedCornerShape(14.dp), color = CardSurface, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        Column {
                            Text(emp.name, fontWeight = FontWeight.Bold, color = Ink)
                            Text(
                                "${emp.salaryType?.name ?: "-"} · Rp ${formatter.format(emp.salaryBase ?: 0.0)}",
                                color = InkSoft, style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        Row {
                            TextButton(onClick = { scope.launch { repository.checkIn(emp.id, null) } }) { Text("Masuk", color = Good) }
                            TextButton(onClick = { scope.launch { repository.checkOut(emp.id) } }) { Text("Pulang", color = Warn) }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Cabang", fontWeight = FontWeight.Bold, color = Ink)
            TextButton(onClick = { showAddBranch = true }) { Text("+ Tambah", color = Teal) }
        }
        Spacer(Modifier.height(8.dp))

        if (branches.isEmpty()) {
            Text("Belum ada cabang tambahan. Semua data saat ini dianggap 1 cabang utama.", color = InkSoft, style = MaterialTheme.typography.bodyMedium)
        } else {
            branches.forEach { branch ->
                Surface(shape = RoundedCornerShape(14.dp), color = CardSurface, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text(branch.name, fontWeight = FontWeight.Bold, color = Ink)
                        branch.address?.let { Text(it, color = InkSoft, style = MaterialTheme.typography.bodyMedium) }
                    }
                }
            }
        }

        if (auditLog.isNotEmpty()) {
            Spacer(Modifier.height(20.dp))
            Text("Riwayat Aktivitas", fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(8.dp))
            val dateFormat = remember { java.text.SimpleDateFormat("dd MMM, HH:mm", Locale("in", "ID")) }
            auditLog.take(20).forEach { log ->
                Surface(shape = RoundedCornerShape(14.dp), color = CardSurface, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(log.action, fontWeight = FontWeight.Bold, color = Ink, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "${dateFormat.format(java.util.Date(log.createdAt))} · ${log.oldValue ?: "-"} → ${log.newValue ?: "-"}",
                            color = InkSoft, style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
        }
    }

    if (showAddBranch) {
        AddBranchSheet(businessId, repository) { showAddBranch = false }
    }

    if (showAddEmployee) {
        AddEmployeeSheet(businessId, repository) { showAddEmployee = false }
    }
    if (showTutupKasir) {
        TutupKasirDialog(expectedCash, repository) { showTutupKasir = false }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddEmployeeSheet(businessId: String, repository: KelolaRepository, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var salaryType by remember { mutableStateOf(SalaryType.HARIAN) }
    var salaryBase by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Sage) {
        Column(Modifier.fillMaxWidth().padding(20.dp).padding(bottom = 32.dp)) {
            Text("Tambah Karyawan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(name, { name = it }, label = { Text("Nama") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(phone, { phone = it }, label = { Text("No. HP (opsional)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = salaryType == SalaryType.HARIAN, onClick = { salaryType = SalaryType.HARIAN }, label = { Text("Harian") })
                FilterChip(selected = salaryType == SalaryType.BULANAN, onClick = { salaryType = SalaryType.BULANAN }, label = { Text("Bulanan") })
                FilterChip(selected = salaryType == SalaryType.KOMISI, onClick = { salaryType = SalaryType.KOMISI }, label = { Text("Komisi") })
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(salaryBase, { salaryBase = it.filter(Char::isDigit) }, label = { Text("Nominal gaji (Rp)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        scope.launch {
                            repository.addEmployee(businessId, null, name.trim(), phone.ifBlank { null }, salaryType, salaryBase.toDoubleOrNull() ?: 0.0)
                            onDismiss()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Mustard, contentColor = Ink),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Simpan") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddBranchSheet(businessId: String, repository: KelolaRepository, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Sage) {
        Column(Modifier.fillMaxWidth().padding(20.dp).padding(bottom = 32.dp)) {
            Text("Tambah Cabang", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(name, { name = it }, label = { Text("Nama cabang") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(address, { address = it }, label = { Text("Alamat (opsional)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        scope.launch {
                            repository.addBranch(businessId, name.trim(), address.ifBlank { null })
                            onDismiss()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Mustard, contentColor = Ink),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Simpan") }
        }
    }
}

@Composable
private fun TutupKasirDialog(expectedCash: Double, repository: KelolaRepository, onDismiss: () -> Unit) {
    var actualText by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val formatter = remember { NumberFormat.getNumberInstance(Locale("in", "ID")) }
    val actual = actualText.toDoubleOrNull() ?: 0.0
    val diff = actual - expectedCash

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tutup Kasir") },
        text = {
            Column {
                Text("Seharusnya: Rp ${formatter.format(expectedCash)}", color = InkSoft)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(actualText, { actualText = it.filter(Char::isDigit) }, label = { Text("Kas aktual (Rp)") }, modifier = Modifier.fillMaxWidth())
                if (actualText.isNotBlank() && diff != 0.0) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Selisih: ${if (diff < 0) "-" else "+"}Rp ${formatter.format(kotlin.math.abs(diff))}",
                        color = if (diff < 0) Warn else Good, fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(reason, { reason = it }, label = { Text("Alasan selisih") }, modifier = Modifier.fillMaxWidth())
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    repository.closeCashier(null, null, expectedCash, actual, reason.ifBlank { null })
                    onDismiss()
                }
            }) { Text("Simpan", color = Teal) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}
