package com.kelola.app.data.local.dao

import androidx.room.*
import com.kelola.app.data.local.entity.Attendance
import com.kelola.app.data.local.entity.CashierClosing
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(attendance: Attendance)

    @Update
    suspend fun update(attendance: Attendance)

    @Query("SELECT * FROM attendance WHERE userId = :userId ORDER BY checkIn DESC LIMIT 1")
    suspend fun getLatestForUser(userId: String): Attendance?

    @Query("SELECT * FROM attendance ORDER BY checkIn DESC")
    fun getAll(): Flow<List<Attendance>>
}

@Dao
interface CashierClosingDao {
    @Insert
    suspend fun insert(closing: CashierClosing)

    @Query("SELECT * FROM cashier_closing ORDER BY closedAt DESC")
    fun getAll(): Flow<List<CashierClosing>>

    @Query("SELECT * FROM cashier_closing ORDER BY closedAt DESC LIMIT 1")
    suspend fun getLatest(): CashierClosing?
}
