package com.kelola.app.ui.servis

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kelola.app.data.local.entity.ServiceStatus
import com.kelola.app.data.local.entity.ServiceTicket
import com.kelola.app.data.repository.KelolaRepository
import com.kelola.app.ui.theme.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServisScreen(businessId: String, repository: KelolaRepository) {
    val tickets by repository.getServiceTickets().collectAsState(initial = emptyList())
    var showAddSheet by remember { mutableStateOf(false) }
    var detailTarget by remember { mutableStateOf<ServiceTicket?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddSheet = true }, containerColor = Mustard, contentColor = Ink) {
                Text("+", style = MaterialTheme.typography.titleLarge)
            }
        },
        containerColor = Sage
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            Text("Servis", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(16.dp))

            if (tickets.isEmpty()) {
                Text("Belum ada servis masuk. Tap + untuk menambahkan.", color = InkSoft)
            } else {
                tickets.forEach { ticket ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = CardSurface,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clickableCompat { detailTarget = ticket }
                                .padding(14.dp)
                        ) {
                            Text(ticket.deviceDesc, fontWeight = FontWeight.Bold, color = Ink)
                            Text(ticket.complaint, color = InkSoft, style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(6.dp))
                            StatusBadge(ticket.status)
                        }
                    }
                }
            }
        }
    }

    if (showAddSheet) {
        AddServiceSheet(businessId, repository) { showAddSheet = false }
    }

    detailTarget?.let { ticket ->
        ServiceDetailDialog(ticket, repository) { detailTarget = null }
    }
}

@Composable
private fun StatusBadge(status: ServiceStatus) {
    val (bg, fg) = when (status) {
        ServiceStatus.SELESAI, ServiceStatus.DIAMBIL -> GoodBg to Good
        ServiceStatus.DITERIMA, ServiceStatus.DIAGNOSA -> WarnBg to Warn
        else -> GoodBg to Teal
    }
    Surface(shape = RoundedCornerShape(20.dp), color = bg) {
        Text(status.name, color = fg, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddServiceSheet(businessId: String, repository: KelolaRepository, onDismiss: () -> Unit) {
    var deviceDesc by remember { mutableStateOf("") }
    var complaint by remember { mutableStateOf("") }
    var estCost by remember { mutableStateOf("") }
    var warrantyDays by remember { mutableStateOf("30") }
    val scope = rememberCoroutineScope()

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Sage) {
        Column(Modifier.fillMaxWidth().padding(20.dp).padding(bottom = 32.dp)) {
            Text("Servis Baru", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(deviceDesc, { deviceDesc = it }, label = { Text("Barang (mis. iPhone 11)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(complaint, { complaint = it }, label = { Text("Keluhan") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(estCost, { estCost = it.filter(Char::isDigit) }, label = { Text("Estimasi biaya (Rp)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(warrantyDays, { warrantyDays = it.filter(Char::isDigit) }, label = { Text("Garansi (hari)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    if (deviceDesc.isNotBlank() && complaint.isNotBlank()) {
                        scope.launch {
                            repository.createServiceTicket(
                                businessId = businessId,
                                deviceDesc = deviceDesc.trim(),
                                complaint = complaint.trim(),
                                estimatedCost = estCost.toDoubleOrNull() ?: 0.0,
                                warrantyDays = warrantyDays.toIntOrNull() ?: 30
                            )
                            onDismiss()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Mustard, contentColor = Ink),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Simpan") }
        }
    }
}

@Composable
private fun ServiceDetailDialog(ticket: ServiceTicket, repository: KelolaRepository, onDismiss: () -> Unit) {
    var finalCostText by remember { mutableStateOf(ticket.estimatedCost.toInt().toString()) }
    val scope = rememberCoroutineScope()
    val formatter = remember { NumberFormat.getNumberInstance(Locale("in", "ID")) }
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale("in", "ID")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(ticket.deviceDesc) },
        text = {
            Column {
                Text(ticket.complaint, color = InkSoft)
                Spacer(Modifier.height(10.dp))
                Text("Status saat ini: ${ticket.status.name}", fontWeight = FontWeight.Bold)
                if (ticket.warrantyUntil != null) {
                    Spacer(Modifier.height(6.dp))
                    Text("Garansi sampai: ${dateFormat.format(Date(ticket.warrantyUntil))}", color = Good)
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    finalCostText, { finalCostText = it.filter(Char::isDigit) },
                    label = { Text("Biaya final (Rp)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Text("Ubah status ke:", color = InkSoft, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(6.dp))
                ServiceStatus.values().forEach { status ->
                    TextButton(onClick = {
                        scope.launch {
                            repository.updateServiceStatus(ticket, status, finalCostText.toDoubleOrNull())
                            onDismiss()
                        }
                    }) { Text(status.name, color = Teal) }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Tutup") }
        }
    )
}

// Helper kecil supaya Card di-tap membuka detail
private fun Modifier.clickableCompat(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)
