package com.kelola.app.data.local.dao

import androidx.room.*
import com.kelola.app.data.local.entity.ProductBom
import com.kelola.app.data.local.entity.ServiceTicket
import kotlinx.coroutines.flow.Flow

@Dao
interface ServiceTicketDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(ticket: ServiceTicket)

    @Update
    suspend fun update(ticket: ServiceTicket)

    @Query("SELECT * FROM service_tickets WHERE deletedAt IS NULL ORDER BY createdAt DESC")
    fun getAll(): Flow<List<ServiceTicket>>

    @Query("SELECT * FROM service_tickets WHERE id = :id")
    suspend fun getById(id: String): ServiceTicket?
}

@Dao
interface ProductBomDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bom: ProductBom)

    @Query("SELECT * FROM product_bom WHERE productId = :productId")
    suspend fun getForProduct(productId: String): List<ProductBom>

    @Query("DELETE FROM product_bom WHERE productId = :productId")
    suspend fun clearForProduct(productId: String)
}
