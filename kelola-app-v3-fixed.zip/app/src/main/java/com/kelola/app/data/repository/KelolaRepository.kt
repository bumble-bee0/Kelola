package com.kelola.app.data.repository

import com.kelola.app.data.local.AppDatabase
import com.kelola.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class KelolaRepository(private val db: AppDatabase) {

    // ---------- Business ----------
    fun getActiveBusiness(): Flow<Business?> = db.businessDao().getActiveBusiness()

    suspend fun hasBusiness(): Boolean = db.businessDao().count() > 0

    suspend fun createBusiness(name: String, type: BusinessType, mode: BusinessMode): String {
        val id = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        db.businessDao().insert(
            Business(id = id, name = name, businessType = type, mode = mode, createdAt = now, updatedAt = now)
        )
        return id
    }

    // ---------- Product ----------
    fun getProducts(): Flow<List<Product>> = db.productDao().getAll()

    suspend fun addProduct(businessId: String, name: String, price: Double, costPrice: Double, initialStock: Int) {
        db.productDao().insert(
            Product(
                id = UUID.randomUUID().toString(),
                businessId = businessId,
                name = name,
                price = price,
                costPrice = costPrice,
                stockQty = initialStock,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    // ---------- Customer / Supplier ----------
    fun getCustomers(): Flow<List<Customer>> = db.customerDao().getAll()
    fun getSuppliers(): Flow<List<Supplier>> = db.supplierDao().getAll()

    // ---------- Transaction (Universal Order Engine) ----------
    fun getTransactions(): Flow<List<TransactionEntity>> = db.transactionDao().getAll()

    /**
     * Mencatat transaksi PENJUALAN atau PENGELUARAN sederhana (1 item bebas, tanpa produk terikat).
     * Kalau productId diisi, stok otomatis dikurangi/ditambah sesuai tipe transaksi.
     */
    suspend fun addSimpleTransaction(
        businessId: String,
        type: TransactionType,
        description: String,
        amount: Double,
        productId: String? = null,
        qty: Int = 1,
        customerId: String? = null,
        supplierId: String? = null,
        paymentStatus: PaymentStatus = PaymentStatus.LUNAS,
        branchId: String? = null
    ) {
        val now = System.currentTimeMillis()
        val txId = UUID.randomUUID().toString()

        db.transactionDao().insertTransaction(
            TransactionEntity(
                id = txId,
                businessId = businessId,
                branchId = branchId,
                type = type,
                customerId = customerId,
                supplierId = supplierId,
                paymentStatus = paymentStatus,
                totalAmount = amount,
                paidAmount = if (paymentStatus == PaymentStatus.LUNAS) amount else 0.0,
                createdAt = now
            )
        )

        db.transactionDao().insertItem(
            TransactionItem(
                id = UUID.randomUUID().toString(),
                transactionId = txId,
                productId = productId,
                description = description,
                qty = qty,
                price = amount
            )
        )

        if (paymentStatus == PaymentStatus.LUNAS) {
            db.transactionDao().insertPayment(
                Payment(id = UUID.randomUUID().toString(), transactionId = txId, amount = amount, paidAt = now)
            )
        }

        // Stok: penjualan mengurangi, pengeluaran (pembelian stok) menambah
        if (productId != null) {
            val delta = when (type) {
                TransactionType.PENJUALAN -> -qty
                TransactionType.PENGELUARAN -> qty
                TransactionType.SERVIS -> 0
            }
            if (delta != 0) db.productDao().adjustStock(productId, delta)
        }
    }

    // ---------- P1: Stock Opname ----------
    /**
     * Koreksi stok manual (stock opname). Selalu wajib disertai alasan,
     * dan tercatat di stock_movements sebagai event, bukan cuma angka akhir.
     */
    suspend fun stockOpname(productId: String, newQty: Int, reason: String, userId: String? = null) {
        val product = db.productDao().getById(productId) ?: return
        val delta = newQty - product.stockQty
        if (delta == 0) return
        db.productDao().adjustStock(productId, delta)
        db.stockMovementDao().insert(
            StockMovement(
                id = UUID.randomUUID().toString(),
                productId = productId,
                type = StockMovementType.ADJUSTMENT,
                qty = delta,
                reason = reason,
                createdBy = userId,
                createdAt = System.currentTimeMillis()
            )
        )
        db.auditLogDao().insert(
            AuditLog(
                id = UUID.randomUUID().toString(),
                userId = userId,
                action = "STOCK_OPNAME",
                entityType = "product",
                entityId = productId,
                oldValue = product.stockQty.toString(),
                newValue = newQty.toString(),
                createdAt = System.currentTimeMillis()
            )
        )
    }

    fun getStockMovements(productId: String): Flow<List<StockMovement>> = db.stockMovementDao().getForProduct(productId)

    // ---------- P1: Piutang/Hutang ----------
    fun getPiutang(): Flow<List<TransactionEntity>> {
        return db.transactionDao().getAll()
            .map { list -> list.filter { it.paymentStatus != PaymentStatus.LUNAS && it.deletedAt == null } }
    }

    suspend fun markAsLunas(transactionId: String, sisaAmount: Double) {
        db.transactionDao().insertPayment(
            Payment(
                id = UUID.randomUUID().toString(),
                transactionId = transactionId,
                amount = sisaAmount,
                paidAt = System.currentTimeMillis()
            )
        )
        // Catatan: status paymentStatus di tabel transactions idealnya diupdate lewat
        // query UPDATE khusus. Untuk kesederhanaan P1, status final dihitung dari
        // total(payments) vs totalAmount saat menampilkan data (lihat LaporanScreen).
    }

    // ---------- P1: Retur ----------
    suspend fun addReturn(originalTransactionId: String, productId: String?, qty: Int, amount: Double) {
        val now = System.currentTimeMillis()
        db.transactionDao().insertItem(
            TransactionItem(
                id = UUID.randomUUID().toString(),
                transactionId = originalTransactionId,
                productId = productId,
                description = "Retur",
                qty = qty,
                price = -amount,
                isReturn = true
            )
        )
        if (productId != null) {
            db.productDao().adjustStock(productId, qty) // barang kembali ke stok
            db.stockMovementDao().insert(
                StockMovement(
                    id = UUID.randomUUID().toString(),
                    productId = productId,
                    type = StockMovementType.RETURN,
                    qty = qty,
                    reason = "Retur transaksi",
                    refTransactionId = originalTransactionId,
                    createdAt = now
                )
            )
        }
    }

    // ---------- P1: Audit Log ----------
    fun getAuditLog(): Flow<List<AuditLog>> = db.auditLogDao().getRecent()

    // ================= P2 =================

    // ---------- Servis + Garansi ----------
    fun getServiceTickets(): Flow<List<ServiceTicket>> = db.serviceTicketDao().getAll()

    suspend fun createServiceTicket(
        businessId: String,
        deviceDesc: String,
        complaint: String,
        estimatedCost: Double,
        warrantyDays: Int,
        customerId: String? = null,
        technicianId: String? = null
    ) {
        db.serviceTicketDao().insert(
            ServiceTicket(
                id = UUID.randomUUID().toString(),
                businessId = businessId,
                customerId = customerId,
                deviceDesc = deviceDesc,
                complaint = complaint,
                technicianId = technicianId,
                estimatedCost = estimatedCost,
                warrantyDays = warrantyDays,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    /**
     * Update status tiket servis. Saat status berubah jadi SELESAI, garansi
     * otomatis dihitung dari tanggal itu + warrantyDays.
     */
    suspend fun updateServiceStatus(ticket: ServiceTicket, newStatus: ServiceStatus, finalCost: Double? = null) {
        val now = System.currentTimeMillis()
        val warrantyUntil = if (newStatus == ServiceStatus.SELESAI) {
            now + (ticket.warrantyDays.toLong() * 24 * 60 * 60 * 1000)
        } else ticket.warrantyUntil

        db.serviceTicketDao().update(
            ticket.copy(
                status = newStatus,
                finalCost = finalCost ?: ticket.finalCost,
                warrantyUntil = warrantyUntil
            )
        )

        // Kalau servis diambil & sudah ada biaya final, catat sebagai transaksi PENJUALAN
        if (newStatus == ServiceStatus.DIAMBIL && (finalCost ?: ticket.finalCost) > 0) {
            addSimpleTransaction(
                businessId = ticket.businessId,
                type = TransactionType.SERVIS,
                description = "Servis: ${ticket.deviceDesc}",
                amount = finalCost ?: ticket.finalCost,
                customerId = ticket.customerId
            )
        }
    }

    // ---------- Resep/BOM + HPP otomatis ----------
    suspend fun setProductBom(productId: String, ingredients: List<Pair<String, Double>>) {
        db.productBomDao().clearForProduct(productId)
        var totalCost = 0.0
        for ((ingredientId, qty) in ingredients) {
            db.productBomDao().insert(
                ProductBom(id = UUID.randomUUID().toString(), productId = productId, ingredientProductId = ingredientId, qtyNeeded = qty)
            )
            val ingredientProduct = db.productDao().getById(ingredientId)
            totalCost += (ingredientProduct?.costPrice ?: 0.0) * qty
        }
        // Pre-calculate HPP saat resep berubah — bukan real-time saat transaksi
        val product = db.productDao().getById(productId)
        if (product != null) {
            db.productDao().update(product.copy(costPrice = totalCost))
        }
    }

    suspend fun getProductBom(productId: String) = db.productBomDao().getForProduct(productId)

    // ---------- Kadaluarsa ----------
    suspend fun setProductExpiry(productId: String, expiryDate: Long?) {
        val product = db.productDao().getById(productId) ?: return
        db.productDao().update(product.copy(expiryDate = expiryDate))
    }

    // ---------- Karyawan + Absensi ----------
    fun getEmployees(businessId: String): Flow<List<AppUser>> = db.userDao().getForBusiness(businessId)

    suspend fun addEmployee(
        businessId: String,
        branchId: String?,
        name: String,
        phone: String?,
        salaryType: SalaryType,
        salaryBase: Double
    ) {
        db.userDao().insert(
            AppUser(
                id = UUID.randomUUID().toString(),
                businessId = businessId,
                branchId = branchId,
                name = name,
                phone = phone,
                role = UserRole.KARYAWAN,
                salaryType = salaryType,
                salaryBase = salaryBase,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun checkIn(userId: String, branchId: String?) {
        db.attendanceDao().insert(
            Attendance(id = UUID.randomUUID().toString(), userId = userId, branchId = branchId, checkIn = System.currentTimeMillis())
        )
    }

    suspend fun checkOut(userId: String) {
        val latest = db.attendanceDao().getLatestForUser(userId) ?: return
        if (latest.checkOut == null) {
            db.attendanceDao().update(latest.copy(checkOut = System.currentTimeMillis()))
        }
    }

    fun getAttendance(): Flow<List<Attendance>> = db.attendanceDao().getAll()

    // ---------- Tutup Kasir ----------
    suspend fun closeCashier(branchId: String?, userId: String?, expectedCash: Double, actualCash: Double, reason: String?) {
        db.cashierClosingDao().insert(
            CashierClosing(
                id = UUID.randomUUID().toString(),
                branchId = branchId,
                userId = userId,
                expectedCash = expectedCash,
                actualCash = actualCash,
                difference = actualCash - expectedCash,
                reason = reason,
                closedAt = System.currentTimeMillis()
            )
        )
    }

    fun getCashierClosings(): Flow<List<CashierClosing>> = db.cashierClosingDao().getAll()

    // ================= P3 =================

    // ---------- Multi-cabang ----------
    fun getBranches(businessId: String): Flow<List<Branch>> = db.branchDao().getForBusiness(businessId)

    suspend fun addBranch(businessId: String, name: String, address: String?) {
        db.branchDao().insert(
            Branch(id = UUID.randomUUID().toString(), businessId = businessId, name = name, address = address, createdAt = System.currentTimeMillis())
        )
    }

    // ---------- Laporan Konsolidasi per Cabang ----------
    data class BranchPerformance(val branchName: String, val omzet: Double, val pengeluaran: Double, val laba: Double, val jumlahTransaksi: Int)

    fun getConsolidatedReportFlow(businessId: String): Flow<List<BranchPerformance>> {
        val branchesFlow = db.branchDao().getForBusiness(businessId)
        val txFlow = db.transactionDao().getAll()
        return kotlinx.coroutines.flow.combine(branchesFlow, txFlow) { branches, transactions ->
            branches.map { branch ->
                val branchTx = transactions.filter { it.branchId == branch.id && it.deletedAt == null }
                val omzet = branchTx.filter { it.type == TransactionType.PENJUALAN }.sumOf { it.totalAmount }
                val pengeluaran = branchTx.filter { it.type == TransactionType.PENGELUARAN }.sumOf { it.totalAmount }
                BranchPerformance(branch.name, omzet, pengeluaran, omzet - pengeluaran, branchTx.size)
            }
        }
    }

    // ---------- Insight Otomatis ("Kenapa laba turun?") ----------
    /**
     * Rule-based sederhana: bandingkan 30 hari terakhir vs 30 hari sebelumnya.
     * Belum pakai AI generatif — cukup statistik dasar, murah dan bisa offline.
     */
    fun getInsightFlow(): Flow<String> {
        return db.transactionDao().getAll().map { transactions ->
            val now = System.currentTimeMillis()
            val day = 24L * 60 * 60 * 1000
            val currentStart = now - 30 * day
            val prevStart = now - 60 * day

            val current = transactions.filter { it.createdAt in currentStart..now }
            val previous = transactions.filter { it.createdAt in prevStart until currentStart }

            fun laba(list: List<TransactionEntity>): Double {
                val omzet = list.filter { it.type == TransactionType.PENJUALAN }.sumOf { it.totalAmount }
                val keluar = list.filter { it.type == TransactionType.PENGELUARAN }.sumOf { it.totalAmount }
                return omzet - keluar
            }

            val labaSekarang = laba(current)
            val labaSebelumnya = laba(previous)

            when {
                previous.isEmpty() -> "Belum cukup data dari bulan sebelumnya untuk membandingkan tren."
                labaSebelumnya == 0.0 -> "Laba 30 hari terakhir: Rp${labaSekarang.toInt()}."
                labaSekarang > labaSebelumnya -> {
                    val persen = ((labaSekarang - labaSebelumnya) / kotlin.math.abs(labaSebelumnya) * 100).toInt()
                    "Laba naik $persen% dibanding 30 hari sebelumnya. Pertahankan performa ini."
                }
                labaSekarang < labaSebelumnya -> {
                    val persen = ((labaSebelumnya - labaSekarang) / kotlin.math.abs(labaSebelumnya) * 100).toInt()
                    val pengeluaranNaik = current.filter { it.type == TransactionType.PENGELUARAN }.sumOf { it.totalAmount } >
                        previous.filter { it.type == TransactionType.PENGELUARAN }.sumOf { it.totalAmount }
                    val penyebab = if (pengeluaranNaik) "kenaikan pengeluaran" else "penurunan penjualan"
                    "Laba turun $persen% dibanding 30 hari sebelumnya, kemungkinan besar karena $penyebab."
                }
                else -> "Laba relatif stabil dibanding 30 hari sebelumnya."
            }
        }
    }
}

