package com.kelola.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "branches")
data class Branch(
    @PrimaryKey val id: String,
    val businessId: String,
    val name: String,
    val address: String? = null,
    val createdAt: Long,
    val deletedAt: Long? = null
)
