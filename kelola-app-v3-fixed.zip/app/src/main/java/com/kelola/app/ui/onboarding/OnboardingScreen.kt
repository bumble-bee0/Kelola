package com.kelola.app.ui.onboarding

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.kelola.app.R
import com.kelola.app.data.local.entity.BusinessMode
import com.kelola.app.data.local.entity.BusinessType
import com.kelola.app.data.repository.KelolaRepository
import com.kelola.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(
    repository: KelolaRepository,
    onFinished: () -> Unit
) {
    var step by remember { mutableStateOf(1) }
    var businessName by remember { mutableStateOf("") }
    var businessType by remember { mutableStateOf<BusinessType?>(null) }
    var businessMode by remember { mutableStateOf<BusinessMode?>(null) }
    val scope = rememberCoroutineScope()

    Scaffold(containerColor = Sage) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            when (step) {
                1 -> {
                    Image(
                        painter = painterResource(id = R.drawable.ic_kelola_logo),
                        contentDescription = "Logo Kelola",
                        modifier = Modifier.height(56.dp)
                    )
                    Spacer(Modifier.height(24.dp))
                    Text("Apa nama usaha kamu?", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(
                        value = businessName,
                        onValueChange = { businessName = it },
                        label = { Text("Nama usaha") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = { if (businessName.isNotBlank()) step = 2 },
                        colors = ButtonDefaults.buttonColors(containerColor = Mustard, contentColor = Ink),
                        modifier = Modifier.align(Alignment.End)
                    ) { Text("Lanjut") }
                }

                2 -> {
                    Text("Usaha kamu bergerak di bidang apa?", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(16.dp))
                    OptionCard("🛍️ Toko / Retail", businessType == BusinessType.RETAIL) { businessType = BusinessType.RETAIL }
                    OptionCard("🍜 Makanan & Minuman", businessType == BusinessType.FNB) { businessType = BusinessType.FNB }
                    OptionCard("🔧 Jasa Servis", businessType == BusinessType.JASA_SERVIS) { businessType = BusinessType.JASA_SERVIS }
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = { if (businessType != null) step = 3 },
                        colors = ButtonDefaults.buttonColors(containerColor = Mustard, contentColor = Ink),
                        modifier = Modifier.align(Alignment.End)
                    ) { Text("Lanjut") }
                }

                3 -> {
                    Text("Kamu jalankan usaha sendiri atau bersama tim?", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(16.dp))
                    OptionCard("👤 Saya sendiri (Solo)", businessMode == BusinessMode.SOLO) { businessMode = BusinessMode.SOLO }
                    OptionCard("👥 Saya punya karyawan/cabang (Tim)", businessMode == BusinessMode.TEAM) { businessMode = BusinessMode.TEAM }
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = {
                            val type = businessType
                            val mode = businessMode
                            if (type != null && mode != null) {
                                scope.launch {
                                    repository.createBusiness(businessName.trim(), type, mode)
                                    onFinished()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Teal, contentColor = Sage),
                        modifier = Modifier.align(Alignment.End)
                    ) { Text("Mulai Pakai Kelola") }
                }
            }
        }
    }
}

@Composable
private fun OptionCard(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .selectable(selected = selected, onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) Teal else CardSurface,
        tonalElevation = 0.dp
    ) {
        Text(
            label,
            modifier = Modifier.padding(16.dp),
            color = if (selected) Sage else Ink
        )
    }
}
