package com.kelola.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class BusinessType { RETAIL, FNB, JASA_SERVIS }
enum class BusinessMode { SOLO, TEAM }

@Entity(tableName = "businesses")
data class Business(
    @PrimaryKey val id: String,
    val name: String,
    val businessType: BusinessType,
    val mode: BusinessMode,
    val createdAt: Long,
    val updatedAt: Long
)
