package com.kelola.app.ui.laporan

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kelola.app.data.local.entity.TransactionType
import com.kelola.app.data.repository.KelolaRepository
import com.kelola.app.ui.theme.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

@Composable
fun LaporanScreen(businessId: String, repository: KelolaRepository) {
    val transactions by repository.getTransactions().collectAsState(initial = emptyList())
    val piutang by repository.getPiutang().collectAsState(initial = emptyList())
    val branchPerformance by repository.getConsolidatedReportFlow(businessId).collectAsState(initial = emptyList())
    val formatter = remember { NumberFormat.getNumberInstance(Locale("in", "ID")) }
    val scope = rememberCoroutineScope()

    val omzet = transactions.filter { it.type == TransactionType.PENJUALAN }.sumOf { it.totalAmount }
    val pengeluaran = transactions.filter { it.type == TransactionType.PENGELUARAN }.sumOf { it.totalAmount }
    val laba = omzet - pengeluaran
    val totalPiutang = piutang.sumOf { it.totalAmount - it.paidAmount }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Laporan", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(16.dp))

        // KPI Grid 2x2
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KpiCard("Omzet", "Rp ${formatter.format(omzet)}", Ink, Modifier.weight(1f))
            KpiCard("Pengeluaran", "Rp ${formatter.format(pengeluaran)}", Warn, Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            KpiCard("Estimasi Laba", "Rp ${formatter.format(laba)}", Good, Modifier.weight(1f))
            KpiCard("Piutang", "Rp ${formatter.format(totalPiutang)}", Warn, Modifier.weight(1f))
        }

        Spacer(Modifier.height(24.dp))
        Text("Piutang Belum Lunas", fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(8.dp))

        if (piutang.isEmpty()) {
            Text("Tidak ada piutang aktif. Semua transaksi lunas.", color = InkSoft, style = MaterialTheme.typography.bodyMedium)
        } else {
            piutang.forEach { tx ->
                val sisa = tx.totalAmount - tx.paidAmount
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = CardSurface,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(tx.paymentStatus.name, color = Ink, fontWeight = FontWeight.Bold)
                            Text("Sisa: Rp ${formatter.format(sisa)}", color = Warn, style = MaterialTheme.typography.bodyMedium)
                        }
                        TextButton(onClick = {
                            scope.launch { repository.markAsLunas(tx.id, sisa) }
                        }) { Text("Tandai Lunas", color = Teal) }
                    }
                }
            }
        }

        if (branchPerformance.isNotEmpty()) {
            Spacer(Modifier.height(24.dp))
            Text("Performa per Cabang", fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(8.dp))
            branchPerformance.forEach { perf ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = CardSurface,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(perf.branchName, fontWeight = FontWeight.Bold, color = Ink)
                        Spacer(Modifier.height(4.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Omzet: Rp ${formatter.format(perf.omzet)}", color = Good, style = MaterialTheme.typography.bodyMedium)
                            Text("Laba: Rp ${formatter.format(perf.laba)}", color = Teal, style = MaterialTheme.typography.bodyMedium)
                        }
                        Text("${perf.jumlahTransaksi} transaksi", color = InkSoft, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiCard(label: String, value: String, valueColor: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(14.dp), color = CardSurface, modifier = modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = InkSoft, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            Text(value, color = valueColor, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        }
    }
}
