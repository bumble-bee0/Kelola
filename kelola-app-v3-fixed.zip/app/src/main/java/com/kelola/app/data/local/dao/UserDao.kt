package com.kelola.app.data.local.dao

import androidx.room.*
import com.kelola.app.data.local.entity.AppUser
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(user: AppUser)

    @Update
    suspend fun update(user: AppUser)

    @Query("SELECT * FROM users WHERE businessId = :businessId AND deletedAt IS NULL ORDER BY name ASC")
    fun getForBusiness(businessId: String): Flow<List<AppUser>>

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getById(id: String): AppUser?
}
