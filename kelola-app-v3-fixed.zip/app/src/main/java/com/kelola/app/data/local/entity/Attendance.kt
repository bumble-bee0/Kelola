package com.kelola.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "attendance")
data class Attendance(
    @PrimaryKey val id: String,
    val userId: String,
    val branchId: String? = null,
    val checkIn: Long,
    val checkOut: Long? = null
)

@Entity(tableName = "cashier_closing")
data class CashierClosing(
    @PrimaryKey val id: String,
    val branchId: String? = null,
    val userId: String? = null,
    val expectedCash: Double,
    val actualCash: Double,
    val difference: Double,
    val reason: String? = null,
    val closedAt: Long
)
