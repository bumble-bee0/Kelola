package com.kelola.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: String,
    val businessId: String,
    val branchId: String? = null,
    val name: String,
    val sku: String? = null,
    val price: Double,
    val costPrice: Double = 0.0,
    val trackStock: Boolean = true,
    val stockQty: Int = 0,
    val warrantyDays: Int? = null,
    val expiryDate: Long? = null, // P2: untuk produk dengan masa simpan (F&B)
    val expiryAt: Long? = null, // P2: tanggal kadaluarsa (epoch millis), nullable
    val createdAt: Long,
    val deletedAt: Long? = null
)
