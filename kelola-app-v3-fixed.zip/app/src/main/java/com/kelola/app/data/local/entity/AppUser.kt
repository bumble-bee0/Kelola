package com.kelola.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole { OWNER, ADMIN_CABANG, KARYAWAN }
enum class SalaryType { HARIAN, BULANAN, KOMISI }

@Entity(tableName = "users")
data class AppUser(
    @PrimaryKey val id: String,
    val businessId: String,
    val branchId: String? = null,
    val name: String,
    val phone: String? = null,
    val role: UserRole,
    val salaryType: SalaryType? = null,
    val salaryBase: Double? = null,
    val createdAt: Long,
    val deletedAt: Long? = null
)
