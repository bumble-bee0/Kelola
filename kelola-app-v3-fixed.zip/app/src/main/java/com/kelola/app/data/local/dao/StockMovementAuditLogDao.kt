package com.kelola.app.data.local.dao

import androidx.room.*
import com.kelola.app.data.local.entity.AuditLog
import com.kelola.app.data.local.entity.StockMovement
import kotlinx.coroutines.flow.Flow

@Dao
interface StockMovementDao {
    @Insert
    suspend fun insert(movement: StockMovement)

    @Query("SELECT * FROM stock_movements WHERE productId = :productId ORDER BY createdAt DESC")
    fun getForProduct(productId: String): Flow<List<StockMovement>>
}

@Dao
interface AuditLogDao {
    @Insert
    suspend fun insert(log: AuditLog)

    @Query("SELECT * FROM audit_log ORDER BY createdAt DESC LIMIT 200")
    fun getRecent(): Flow<List<AuditLog>>
}
