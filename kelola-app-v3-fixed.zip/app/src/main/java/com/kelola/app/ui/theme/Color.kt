package com.kelola.app.ui.theme

import androidx.compose.ui.graphics.Color

val Teal = Color(0xFF1F6F5C)
val TealDeep = Color(0xFF164F41)
val Mustard = Color(0xFFE4A63B)
val Sage = Color(0xFFF0F3EC)
val CardSurface = Color(0xFFFAFCF8)
val Ink = Color(0xFF1C2420)
val InkSoft = Color(0xFF5B655D)
val Good = Color(0xFF3F8F5F)
val GoodBg = Color(0xFFE3F0E6)
val Warn = Color(0xFFC4573B)
val WarnBg = Color(0xFFFBE8E2)
val Line = Color(0xFFDDE4D8)
