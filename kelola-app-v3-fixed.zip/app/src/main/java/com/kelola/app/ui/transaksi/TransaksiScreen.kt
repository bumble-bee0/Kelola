package com.kelola.app.ui.transaksi

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kelola.app.data.local.entity.PaymentStatus
import com.kelola.app.data.local.entity.TransactionType
import com.kelola.app.data.repository.KelolaRepository
import com.kelola.app.ui.theme.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TransaksiScreen(businessId: String, repository: KelolaRepository) {
    val transactions by repository.getTransactions().collectAsState(initial = emptyList())
    var showAddSheet by remember { mutableStateOf(false) }
    val formatter = remember { NumberFormat.getNumberInstance(Locale("in", "ID")) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddSheet = true },
                containerColor = Mustard,
                contentColor = Ink
            ) { Text("+", style = MaterialTheme.typography.titleLarge) }
        },
        containerColor = Sage
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            Text("Transaksi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(16.dp))

            if (transactions.isEmpty()) {
                Text("Belum ada transaksi. Tap + untuk mencatat yang pertama.", color = InkSoft)
            } else {
                transactions.forEach { tx ->
                    var showReturDialog by remember { mutableStateOf(false) }
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = CardSurface,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(tx.type.name, fontWeight = FontWeight.Bold, color = Ink)
                                    Text(tx.paymentStatus.name, color = InkSoft, style = MaterialTheme.typography.bodyMedium)
                                }
                                Text(
                                    "Rp ${formatter.format(tx.totalAmount)}",
                                    color = if (tx.type == TransactionType.PENJUALAN) Good else Warn,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (tx.type == TransactionType.PENJUALAN) {
                                TextButton(
                                    onClick = { showReturDialog = true },
                                    modifier = Modifier.align(androidx.compose.ui.Alignment.End)
                                ) { Text("Retur", color = Warn, style = MaterialTheme.typography.bodyMedium) }
                            }
                        }
                    }
                    if (showReturDialog) {
                        ReturDialog(tx.id, tx.totalAmount, repository) { showReturDialog = false }
                    }
                }
            }
        }
    }

    if (showAddSheet) {
        AddTransactionSheet(
            businessId = businessId,
            repository = repository,
            onDismiss = { showAddSheet = false }
        )
    }
}

@Composable
private fun ReturDialog(transactionId: String, originalAmount: Double, repository: KelolaRepository, onDismiss: () -> Unit) {
    var amountText by remember { mutableStateOf(originalAmount.toInt().toString()) }
    var reason by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Retur Transaksi") },
        text = {
            Column {
                Text("Jumlah yang dikembalikan ke pelanggan:", color = InkSoft, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    amountText, { amountText = it.filter(Char::isDigit) },
                    label = { Text("Jumlah retur (Rp)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    reason, { reason = it },
                    label = { Text("Alasan (opsional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val amount = amountText.toDoubleOrNull() ?: 0.0
                if (amount > 0) {
                    scope.launch {
                        repository.addReturn(transactionId, productId = null, qty = 1, amount = amount)
                        onDismiss()
                    }
                }
            }) { Text("Proses Retur", color = Warn) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTransactionSheet(
    businessId: String,
    repository: KelolaRepository,
    onDismiss: () -> Unit
) {
    var type by remember { mutableStateOf(TransactionType.PENJUALAN) }
    var description by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var paymentStatus by remember { mutableStateOf(PaymentStatus.LUNAS) }
    var selectedBranchId by remember { mutableStateOf<String?>(null) }
    val branches by repository.getBranches(businessId).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Sage) {
        Column(Modifier.fillMaxWidth().padding(20.dp).padding(bottom = 32.dp)) {
            Text("Tambah Transaksi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = type == TransactionType.PENJUALAN,
                    onClick = { type = TransactionType.PENJUALAN },
                    label = { Text("Penjualan") }
                )
                FilterChip(
                    selected = type == TransactionType.PENGELUARAN,
                    onClick = { type = TransactionType.PENGELUARAN },
                    label = { Text("Pengeluaran") }
                )
            }

            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Keterangan") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it.filter { c -> c.isDigit() } },
                label = { Text("Jumlah (Rp)") },
                modifier = Modifier.fillMaxWidth()
            )

            if (type == TransactionType.PENJUALAN) {
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = paymentStatus == PaymentStatus.LUNAS,
                        onClick = { paymentStatus = PaymentStatus.LUNAS },
                        label = { Text("Lunas") }
                    )
                    FilterChip(
                        selected = paymentStatus == PaymentStatus.PIUTANG,
                        onClick = { paymentStatus = PaymentStatus.PIUTANG },
                        label = { Text("Piutang (bayar belakangan)") }
                    )
                }
            }

            if (branches.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text("Cabang", color = InkSoft, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    branches.forEach { branch ->
                        FilterChip(
                            selected = selectedBranchId == branch.id,
                            onClick = { selectedBranchId = branch.id },
                            label = { Text(branch.name) }
                        )
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull() ?: 0.0
                    if (amount > 0) {
                        scope.launch {
                            repository.addSimpleTransaction(
                                businessId = businessId,
                                type = type,
                                description = description.ifBlank { type.name },
                                amount = amount,
                                paymentStatus = if (type == TransactionType.PENJUALAN) paymentStatus else PaymentStatus.LUNAS,
                                branchId = selectedBranchId
                            )
                            onDismiss()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Mustard, contentColor = Ink),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Simpan") }
        }
    }
}
