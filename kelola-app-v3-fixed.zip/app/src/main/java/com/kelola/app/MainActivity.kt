package com.kelola.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.kelola.app.data.local.AppDatabase
import com.kelola.app.data.repository.KelolaRepository
import com.kelola.app.ui.navigation.MainNav
import com.kelola.app.ui.onboarding.OnboardingScreen
import com.kelola.app.ui.theme.KelolaTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = AppDatabase.getInstance(applicationContext)
        val repository = KelolaRepository(db)

        setContent {
            KelolaTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    KelolaApp(repository)
                }
            }
        }
    }
}

@Composable
private fun KelolaApp(repository: KelolaRepository) {
    var checking by remember { mutableStateOf(true) }
    var hasBusiness by remember { mutableStateOf(false) }
    val business by repository.getActiveBusiness().collectAsState(initial = null)

    LaunchedEffect(Unit) {
        hasBusiness = repository.hasBusiness()
        checking = false
    }

    when {
        checking -> { /* splash kosong sesaat, bisa diganti splash screen di tahap berikutnya */ }
        !hasBusiness && business == null -> {
            OnboardingScreen(repository = repository, onFinished = { hasBusiness = true })
        }
        business != null -> {
            MainNav(
                businessId = business!!.id,
                businessType = business!!.businessType,
                businessMode = business!!.mode,
                repository = repository
            )
        }
    }
}
