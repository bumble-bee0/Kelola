package com.kelola.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.kelola.app.data.local.entity.BusinessMode
import com.kelola.app.data.local.entity.BusinessType
import com.kelola.app.data.repository.KelolaRepository
import com.kelola.app.ui.beranda.BerandaScreen
import com.kelola.app.ui.laporan.LaporanScreen
import com.kelola.app.ui.produk.ProdukScreen
import com.kelola.app.ui.servis.ServisScreen
import com.kelola.app.ui.theme.Teal
import com.kelola.app.ui.tim.TimScreen
import com.kelola.app.ui.transaksi.TransaksiScreen

sealed class Screen(val route: String, val label: String) {
    object Beranda : Screen("beranda", "Beranda")
    object Transaksi : Screen("transaksi", "Transaksi")
    object Produk : Screen("produk", "Produk")
    object Servis : Screen("servis", "Servis")
    object Laporan : Screen("laporan", "Laporan")
    object Tim : Screen("tim", "Tim")
}

@Composable
fun MainNav(
    businessId: String,
    businessType: BusinessType,
    businessMode: BusinessMode,
    repository: KelolaRepository
) {
    val navController: NavHostController = rememberNavController()

    val bottomItems = buildList {
        add(Screen.Beranda)
        add(Screen.Transaksi)
        add(Screen.Produk)
        if (businessType == BusinessType.JASA_SERVIS) add(Screen.Servis)
        add(Screen.Laporan)
        if (businessMode == BusinessMode.TEAM) add(Screen.Tim)
    }

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination?.route

            NavigationBar(containerColor = Color.White) {
                bottomItems.forEach { screen ->
                    val icon = when (screen) {
                        Screen.Beranda -> Icons.Filled.Home
                        Screen.Transaksi -> Icons.Filled.List
                        Screen.Produk -> Icons.Filled.ShoppingCart
                        Screen.Servis -> Icons.Filled.Build
                        Screen.Laporan -> Icons.Filled.BarChart
                        Screen.Tim -> Icons.Filled.Groups
                    }
                    NavigationBarItem(
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.startDestinationId) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(icon, contentDescription = screen.label) },
                        label = { Text(screen.label) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Teal, selectedTextColor = Teal)
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Beranda.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Beranda.route) { BerandaScreen(repository) }
            composable(Screen.Transaksi.route) { TransaksiScreen(businessId, repository) }
            composable(Screen.Produk.route) { ProdukScreen(businessId, repository) }
            composable(Screen.Servis.route) { ServisScreen(businessId, repository) }
            composable(Screen.Laporan.route) { LaporanScreen(businessId, repository) }
            composable(Screen.Tim.route) { TimScreen(businessId, repository) }
        }
    }
}
