package com.kelola.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey val id: String,
    val businessId: String,
    val name: String,
    val phone: String? = null,
    val notes: String? = null,
    val deletedAt: Long? = null
)

@Entity(tableName = "suppliers")
data class Supplier(
    @PrimaryKey val id: String,
    val businessId: String,
    val name: String,
    val phone: String? = null,
    val deletedAt: Long? = null
)
