package com.kelola.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.kelola.app.data.local.dao.*
import com.kelola.app.data.local.entity.*

@Database(
    entities = [
        Business::class,
        Branch::class,
        AppUser::class,
        Product::class,
        Customer::class,
        Supplier::class,
        TransactionEntity::class,
        TransactionItem::class,
        Payment::class,
        StockMovement::class,
        AuditLog::class,
        ServiceTicket::class,
        ProductBom::class,
        Attendance::class,
        CashierClosing::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun businessDao(): BusinessDao
    abstract fun productDao(): ProductDao
    abstract fun transactionDao(): TransactionDao
    abstract fun customerDao(): CustomerDao
    abstract fun supplierDao(): SupplierDao
    abstract fun stockMovementDao(): StockMovementDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun serviceTicketDao(): ServiceTicketDao
    abstract fun productBomDao(): ProductBomDao
    abstract fun attendanceDao(): AttendanceDao
    abstract fun cashierClosingDao(): CashierClosingDao
    abstract fun userDao(): UserDao
    abstract fun branchDao(): BranchDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kelola.db"
                ).build().also { INSTANCE = it }
            }
    }
}
