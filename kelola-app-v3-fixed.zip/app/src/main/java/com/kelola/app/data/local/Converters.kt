package com.kelola.app.data.local

import androidx.room.TypeConverter
import com.kelola.app.data.local.entity.*

class Converters {
    @TypeConverter fun fromBusinessType(v: BusinessType) = v.name
    @TypeConverter fun toBusinessType(v: String) = BusinessType.valueOf(v)

    @TypeConverter fun fromBusinessMode(v: BusinessMode) = v.name
    @TypeConverter fun toBusinessMode(v: String) = BusinessMode.valueOf(v)

    @TypeConverter fun fromUserRole(v: UserRole) = v.name
    @TypeConverter fun toUserRole(v: String) = UserRole.valueOf(v)

    @TypeConverter fun fromSalaryType(v: SalaryType?) = v?.name
    @TypeConverter fun toSalaryType(v: String?) = v?.let { SalaryType.valueOf(it) }

    @TypeConverter fun fromTransactionType(v: TransactionType) = v.name
    @TypeConverter fun toTransactionType(v: String) = TransactionType.valueOf(v)

    @TypeConverter fun fromTransactionStatus(v: TransactionStatus) = v.name
    @TypeConverter fun toTransactionStatus(v: String) = TransactionStatus.valueOf(v)

    @TypeConverter fun fromPaymentStatus(v: PaymentStatus) = v.name
    @TypeConverter fun toPaymentStatus(v: String) = PaymentStatus.valueOf(v)

    @TypeConverter fun fromStockMovementType(v: StockMovementType) = v.name
    @TypeConverter fun toStockMovementType(v: String) = StockMovementType.valueOf(v)

    @TypeConverter fun fromServiceStatus(v: ServiceStatus) = v.name
    @TypeConverter fun toServiceStatus(v: String) = ServiceStatus.valueOf(v)
}
