package com.kelola.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType { PENJUALAN, PENGELUARAN, SERVIS }
enum class TransactionStatus { DRAFT, SELESAI, DIBATALKAN }
enum class PaymentStatus { LUNAS, PIUTANG, CICILAN }

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val businessId: String,
    val branchId: String? = null,
    val type: TransactionType,
    val customerId: String? = null,
    val supplierId: String? = null,
    val employeeId: String? = null,
    val status: TransactionStatus = TransactionStatus.SELESAI,
    val paymentStatus: PaymentStatus = PaymentStatus.LUNAS,
    val totalAmount: Double,
    val paidAmount: Double = 0.0,
    val notes: String? = null,
    val createdAt: Long,
    val deletedAt: Long? = null
)

@Entity(tableName = "transaction_items")
data class TransactionItem(
    @PrimaryKey val id: String,
    val transactionId: String,
    val productId: String? = null,
    val description: String? = null, // untuk item tanpa produk (mis. jasa/biaya bebas)
    val qty: Int = 1,
    val price: Double,
    val costPrice: Double = 0.0,
    val isReturn: Boolean = false
)

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey val id: String,
    val transactionId: String,
    val amount: Double,
    val method: String = "tunai",
    val paidAt: Long
)
