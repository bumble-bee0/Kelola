package com.kelola.app.ui.produk

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kelola.app.data.local.entity.Product
import com.kelola.app.data.repository.KelolaRepository
import com.kelola.app.ui.theme.*
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProdukScreen(businessId: String, repository: KelolaRepository) {
    val products by repository.getProducts().collectAsState(initial = emptyList())
    var query by remember { mutableStateOf("") }
    var showAddSheet by remember { mutableStateOf(false) }
    var opnameTarget by remember { mutableStateOf<Product?>(null) }
    var expiryTarget by remember { mutableStateOf<Product?>(null) }
    val formatter = remember { NumberFormat.getNumberInstance(Locale("in", "ID")) }

    val filtered = products.filter { it.name.contains(query, ignoreCase = true) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddSheet = true }, containerColor = Mustard, contentColor = Ink) {
                Text("+", style = MaterialTheme.typography.titleLarge)
            }
        },
        containerColor = Sage
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
            Text("Produk", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Cari produk...") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            if (filtered.isEmpty()) {
                Text("Belum ada produk. Tap + untuk menambahkan.", color = InkSoft)
            } else {
                filtered.forEach { product ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = CardSurface,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(product.name, fontWeight = FontWeight.Bold, color = Ink)
                                Text(product.sku ?: "-", color = InkSoft, style = MaterialTheme.typography.bodyMedium)
                            }
                            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                                Text("Rp ${formatter.format(product.price)}", color = Ink, fontWeight = FontWeight.Bold)
                                Text(
                                    "${product.stockQty} pcs",
                                    color = if (product.stockQty <= 3) Warn else InkSoft,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                        // Stock opname dipicu lewat long-press di iterasi mendatang;
                        // untuk P1 disediakan lewat tombol teks sederhana di bawah:
                    }
                    TextButton(onClick = { opnameTarget = product }) {
                        Text("Sesuaikan stok (Stock Opname)", style = MaterialTheme.typography.bodyMedium, color = Teal)
                    }
                    if (product.expiryDate != null) {
                        val daysLeft = ((product.expiryDate - System.currentTimeMillis()) / (24 * 60 * 60 * 1000)).toInt()
                        Text(
                            if (daysLeft >= 0) "Kadaluarsa dalam $daysLeft hari" else "Sudah kadaluarsa",
                            color = if (daysLeft <= 3) Warn else InkSoft,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    TextButton(onClick = { expiryTarget = product }) {
                        Text("Atur tanggal kadaluarsa", style = MaterialTheme.typography.bodyMedium, color = Teal)
                    }
                }
            }
        }
    }

    if (showAddSheet) {
        AddProductSheet(businessId, repository) { showAddSheet = false }
    }

    opnameTarget?.let { product ->
        StockOpnameDialog(product, repository) { opnameTarget = null }
    }

    expiryTarget?.let { product ->
        ExpiryDialog(product, repository) { expiryTarget = null }
    }
}

@Composable
private fun ExpiryDialog(product: Product, repository: KelolaRepository, onDismiss: () -> Unit) {
    var daysFromNow by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Kadaluarsa — ${product.name}") },
        text = {
            OutlinedTextField(
                daysFromNow, { daysFromNow = it.filter(Char::isDigit) },
                label = { Text("Kadaluarsa berapa hari lagi dari sekarang") },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = {
                val days = daysFromNow.toIntOrNull()
                if (days != null) {
                    scope.launch {
                        val expiry = System.currentTimeMillis() + days.toLong() * 24 * 60 * 60 * 1000
                        repository.setProductExpiry(product.id, expiry)
                        onDismiss()
                    }
                }
            }) { Text("Simpan", color = Teal) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddProductSheet(businessId: String, repository: KelolaRepository, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Sage) {
        Column(Modifier.fillMaxWidth().padding(20.dp).padding(bottom = 32.dp)) {
            Text("Tambah Produk", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(name, { name = it }, label = { Text("Nama produk") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(price, { price = it.filter(Char::isDigit) }, label = { Text("Harga jual (Rp)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(cost, { cost = it.filter(Char::isDigit) }, label = { Text("HPP / harga modal (Rp)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(stock, { stock = it.filter(Char::isDigit) }, label = { Text("Stok awal") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = {
                    val p = price.toDoubleOrNull() ?: 0.0
                    val c = cost.toDoubleOrNull() ?: 0.0
                    val s = stock.toIntOrNull() ?: 0
                    if (name.isNotBlank() && p > 0) {
                        scope.launch {
                            repository.addProduct(businessId, name.trim(), p, c, s)
                            onDismiss()
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Mustard, contentColor = Ink),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Simpan") }
        }
    }
}

@Composable
private fun StockOpnameDialog(product: Product, repository: KelolaRepository, onDismiss: () -> Unit) {
    var newQtyText by remember { mutableStateOf(product.stockQty.toString()) }
    var reason by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Stock Opname — ${product.name}") },
        text = {
            Column {
                Text("Stok sistem saat ini: ${product.stockQty} pcs", color = InkSoft)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    newQtyText, { newQtyText = it.filter(Char::isDigit) },
                    label = { Text("Stok fisik sebenarnya") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    reason, { reason = it },
                    label = { Text("Alasan (mis. rusak, hilang, salah input)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val newQty = newQtyText.toIntOrNull()
                if (newQty != null && reason.isNotBlank()) {
                    scope.launch {
                        repository.stockOpname(product.id, newQty, reason)
                        onDismiss()
                    }
                }
            }) { Text("Simpan", color = Teal) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}
