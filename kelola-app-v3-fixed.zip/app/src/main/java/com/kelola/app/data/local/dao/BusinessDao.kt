package com.kelola.app.data.local.dao

import androidx.room.*
import com.kelola.app.data.local.entity.Business
import kotlinx.coroutines.flow.Flow

@Dao
interface BusinessDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(business: Business)

    @Query("SELECT * FROM businesses LIMIT 1")
    fun getActiveBusiness(): Flow<Business?>

    @Query("SELECT COUNT(*) FROM businesses")
    suspend fun count(): Int
}
