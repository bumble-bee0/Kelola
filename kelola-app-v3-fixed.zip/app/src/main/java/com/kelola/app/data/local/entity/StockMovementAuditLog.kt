package com.kelola.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class StockMovementType { IN, OUT, ADJUSTMENT, RETURN, WASTAGE }

@Entity(tableName = "stock_movements")
data class StockMovement(
    @PrimaryKey val id: String,
    val productId: String,
    val type: StockMovementType,
    val qty: Int, // boleh negatif
    val reason: String? = null,
    val refTransactionId: String? = null,
    val createdBy: String? = null,
    val createdAt: Long
)

@Entity(tableName = "audit_log")
data class AuditLog(
    @PrimaryKey val id: String,
    val userId: String? = null,
    val action: String,
    val entityType: String,
    val entityId: String,
    val oldValue: String? = null,
    val newValue: String? = null,
    val createdAt: Long
)
